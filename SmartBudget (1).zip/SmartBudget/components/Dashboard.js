export default function Dashboard() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">SmartBudget Dashboard</h1>
      <p>Добро пожаловать! Здесь будет график доходов и расходов.</p>
    </div>
  )
}